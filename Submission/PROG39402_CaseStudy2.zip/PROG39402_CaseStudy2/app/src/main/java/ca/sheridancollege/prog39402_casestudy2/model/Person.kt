package ca.sheridancollege.prog39402_casestudy2.model

data class Person(val name: String, val image: Int, val link: String)